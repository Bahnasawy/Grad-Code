type LoginResponse = { users: { nodes: Array<{ id: number }> } };
