unmarkedGrammar = '''
NP: {(<DT>?<JJ>*<NN>|<NNS>|<NNP>+|<NNPS>)|<PRP>|(<PRP$> <NN>|<NNS>{1,2})|<DT>}
PH: {<PRP>|<EX>}
NCH: {<WP><PRP>(<VB>|<VBD>)}
'''